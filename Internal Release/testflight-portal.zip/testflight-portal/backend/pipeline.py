"""TestFlight release pipeline: increment build, publish, upload."""

from __future__ import annotations

import asyncio
import re
import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import AsyncIterator, Callable

from config import settings


class StepStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"


class PipelineStatus(str, Enum):
    IDLE = "idle"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"


@dataclass
class PipelineStep:
    id: str
    label: str
    status: StepStatus = StepStatus.PENDING
    detail: str = ""


@dataclass
class ReleaseState:
    status: PipelineStatus = PipelineStatus.IDLE
    steps: list[PipelineStep] = field(default_factory=list)
    logs: list[str] = field(default_factory=list)
    started_at: str | None = None
    finished_at: str | None = None
    current_build: int | None = None
    new_build: int | None = None
    error: str | None = None

    def to_dict(self) -> dict:
        return {
            "status": self.status.value,
            "steps": [
                {"id": s.id, "label": s.label, "status": s.status.value, "detail": s.detail}
                for s in self.steps
            ],
            "logs": self.logs[-500:],
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "current_build": self.current_build,
            "new_build": self.new_build,
            "error": self.error,
        }


BUILD_PATTERN = re.compile(
    r"(<ApplicationVersion>)(\d+)(</ApplicationVersion>)",
    re.IGNORECASE,
)


def read_build_number(csproj: Path) -> int:
    content = csproj.read_text(encoding="utf-8")
    match = BUILD_PATTERN.search(content)
    if not match:
        raise ValueError(f"Could not find <ApplicationVersion> in {csproj}")
    return int(match.group(2))


def increment_build_number(csproj: Path) -> tuple[int, int]:
    content = csproj.read_text(encoding="utf-8")
    match = BUILD_PATTERN.search(content)
    if not match:
        raise ValueError(f"Could not find <ApplicationVersion> in {csproj}")

    old = int(match.group(2))
    new = old + 1
    updated = BUILD_PATTERN.sub(rf"\g<1>{new}\g<3>", content, count=1)
    csproj.write_text(updated, encoding="utf-8")
    return old, new


class ReleasePipeline:
    def __init__(self) -> None:
        self.state = ReleaseState(
            steps=[
                PipelineStep("increment", "Increment build number"),
                PipelineStep("publish", "Build & archive (.ipa)"),
                PipelineStep("upload", "Upload to TestFlight"),
            ]
        )
        self._lock = asyncio.Lock()
        self._log_callbacks: list[Callable[[str], None]] = []

    def subscribe_logs(self, callback: Callable[[str], None]) -> None:
        self._log_callbacks.append(callback)

    def _emit_log(self, line: str) -> None:
        timestamp = datetime.now(timezone.utc).strftime("%H:%M:%S")
        entry = f"[{timestamp}] {line}"
        self.state.logs.append(entry)
        for cb in self._log_callbacks:
            cb(entry)

    def _set_step(self, step_id: str, status: StepStatus, detail: str = "") -> None:
        for step in self.state.steps:
            if step.id == step_id:
                step.status = status
                if detail:
                    step.detail = detail
                break

    async def _run_command(
        self, cmd: list[str], cwd: Path | None = None
    ) -> tuple[int, str]:
        self._emit_log(f"$ {' '.join(cmd)}")

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=str(cwd) if cwd else None,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )

        output_lines: list[str] = []
        assert proc.stdout is not None
        while True:
            chunk = await proc.stdout.readline()
            if not chunk:
                break
            line = chunk.decode("utf-8", errors="replace").rstrip()
            output_lines.append(line)
            self._emit_log(line)

        code = await proc.wait()
        return code, "\n".join(output_lines)

    async def run(self) -> ReleaseState:
        async with self._lock:
            if self.state.status == PipelineStatus.RUNNING:
                raise RuntimeError("A release is already in progress")

            self.state = ReleaseState(
                steps=[
                    PipelineStep("increment", "Increment build number"),
                    PipelineStep("publish", "Build & archive (.ipa)"),
                    PipelineStep("upload", "Upload to TestFlight"),
                ],
                status=PipelineStatus.RUNNING,
                started_at=datetime.now(timezone.utc).isoformat(),
            )

            try:
                await self._step_increment()
                await self._step_publish()
                await self._step_upload()
                self.state.status = PipelineStatus.SUCCESS
                self._emit_log("Release completed successfully.")
            except Exception as exc:
                self.state.status = PipelineStatus.FAILED
                self.state.error = str(exc)
                self._emit_log(f"ERROR: {exc}")
            finally:
                self.state.finished_at = datetime.now(timezone.utc).isoformat()

            return self.state

    async def _step_increment(self) -> None:
        self._set_step("increment", StepStatus.RUNNING)
        csproj = settings.csproj_path
        if not csproj.exists():
            self._set_step("increment", StepStatus.FAILED, "csproj not found")
            raise FileNotFoundError(f"Project file not found: {csproj}")

        old, new = await asyncio.to_thread(increment_build_number, csproj)
        self.state.current_build = old
        self.state.new_build = new
        self._emit_log(f"Build number: {old} → {new}")
        self._set_step("increment", StepStatus.SUCCESS, f"{old} → {new}")

    async def _step_publish(self) -> None:
        self._set_step("publish", StepStatus.RUNNING)
        csproj = settings.csproj_path
        cmd = [
            "dotnet",
            "publish",
            str(csproj),
            "-f",
            settings.dotnet_framework,
            "-c",
            settings.dotnet_configuration,
            f"-p:RuntimeIdentifier={settings.runtime_identifier}",
            "-p:ArchiveOnBuild=true",
        ]
        code, _ = await self._run_command(cmd, cwd=settings.project_root)
        if code != 0:
            self._set_step("publish", StepStatus.FAILED, f"exit code {code}")
            raise RuntimeError(f"dotnet publish failed with exit code {code}")

        ipa = settings.ipa_path
        if not ipa.exists():
            self._set_step("publish", StepStatus.FAILED, "IPA not found")
            raise FileNotFoundError(f"Expected IPA at {ipa}")

        size_mb = ipa.stat().st_size / (1024 * 1024)
        self._set_step("publish", StepStatus.SUCCESS, f"{ipa.name} ({size_mb:.1f} MB)")

    async def _step_upload(self) -> None:
        self._set_step("upload", StepStatus.RUNNING)

        if not settings.apple_id or not settings.apple_app_password:
            self._set_step("upload", StepStatus.FAILED, "Missing Apple credentials")
            raise ValueError(
                "Set APPLE_ID and APPLE_APP_PASSWORD in .env before uploading"
            )

        ipa = settings.ipa_path
        cmd = [
            "xcrun",
            "altool",
            "--upload-app",
            "-f",
            str(ipa),
            "-t",
            "ios",
            "-u",
            settings.apple_id,
            "-p",
            settings.apple_app_password,
        ]
        code, _ = await self._run_command(cmd, cwd=settings.publish_dir)
        if code != 0:
            self._set_step("upload", StepStatus.FAILED, f"exit code {code}")
            raise RuntimeError(f"TestFlight upload failed with exit code {code}")

        self._set_step("upload", StepStatus.SUCCESS, "Uploaded to App Store Connect")


# Singleton pipeline instance
pipeline = ReleasePipeline()


async def get_current_build_preview() -> dict:
    csproj = settings.csproj_path
    if not csproj.exists():
        return {"current": None, "next": None, "csproj_path": str(csproj)}
    current = read_build_number(csproj)
    return {
        "current": current,
        "next": current + 1,
        "csproj_path": str(csproj),
        "ipa_path": str(settings.ipa_path),
    }
