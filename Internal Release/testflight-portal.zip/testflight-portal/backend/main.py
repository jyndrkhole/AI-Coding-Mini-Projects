"""TestFlight Release Portal — FastAPI server."""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from config import settings
from groq_agent import analyze_logs
from pipeline import PipelineStatus, get_current_build_preview, pipeline

FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"


@asynccontextmanager
async def lifespan(_: FastAPI):
    yield


app = FastAPI(title="TestFlight Release Portal", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class AnalyzeRequest(BaseModel):
    question: str | None = None


class AnalyzeResponse(BaseModel):
    analysis: str


@app.get("/api/health")
async def health():
    return {
        "status": "ok",
        "groq_configured": bool(settings.groq_api_key),
        "apple_configured": bool(settings.apple_id and settings.apple_app_password),
    }


@app.get("/api/preview")
async def preview():
    return await get_current_build_preview()


@app.get("/api/status")
async def status():
    return pipeline.state.to_dict()


@app.post("/api/release")
async def start_release():
    if pipeline.state.status == PipelineStatus.RUNNING:
        raise HTTPException(status_code=409, detail="Release already in progress")

    asyncio.create_task(pipeline.run())
    return {"message": "Release started", "status": "running"}


@app.post("/api/analyze", response_model=AnalyzeResponse)
async def analyze(request: AnalyzeRequest):
    logs = "\n".join(pipeline.state.logs)
    if not logs:
        raise HTTPException(status_code=400, detail="No logs available yet")
    analysis = await analyze_logs(logs, request.question)
    return AnalyzeResponse(analysis=analysis)


@app.websocket("/ws/logs")
async def websocket_logs(websocket: WebSocket):
    await websocket.accept()
    queue: asyncio.Queue[str] = asyncio.Queue()

    def on_log(line: str) -> None:
        try:
            queue.put_nowait(line)
        except asyncio.QueueFull:
            pass

    pipeline.subscribe_logs(on_log)

    try:
        # Send existing logs
        for line in pipeline.state.logs:
            await websocket.send_text(line)

        while True:
            try:
                line = await asyncio.wait_for(queue.get(), timeout=30.0)
                await websocket.send_text(line)
            except asyncio.TimeoutError:
                await websocket.send_text("__ping__")
    except WebSocketDisconnect:
        pass
    finally:
        if on_log in pipeline._log_callbacks:
            pipeline._log_callbacks.remove(on_log)


@app.get("/")
async def index():
    return FileResponse(FRONTEND_DIR / "index.html")


app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")
