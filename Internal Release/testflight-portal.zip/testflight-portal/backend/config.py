"""Configuration loaded from environment variables."""

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(Path(__file__).resolve().parent.parent / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # MAUI project
    project_root: Path = Path("/Users/jayendra/Desktop/AgentVizion2Go")
    csproj_path: Path = Path(
        "/Users/jayendra/Desktop/AgentVizion2Go/AgentVizion2Go.MAUI/AgentVizion2Go.MAUI.csproj"
    )
    dotnet_framework: str = "net9.0-ios"
    dotnet_configuration: str = "Release"
    runtime_identifier: str = "ios-arm64"
    ipa_filename: str = "AgentVizion2Go.MAUI.ipa"

    # Apple credentials (use app-specific password, not Apple ID password)
    apple_id: str = ""
    apple_app_password: str = ""

    # Groq (optional — used for log analysis / AI assistant)
    groq_api_key: str = ""
    groq_model: str = "llama-3.3-70b-versatile"

    # Server
    host: str = "127.0.0.1"
    port: int = 8787

    @property
    def publish_dir(self) -> Path:
        return (
            self.project_root
            / "AgentVizion2Go.MAUI"
            / "bin"
            / self.dotnet_configuration
            / self.dotnet_framework
            / self.runtime_identifier
            / "publish"
        )

    @property
    def ipa_path(self) -> Path:
        return self.publish_dir / self.ipa_filename


settings = Settings()
