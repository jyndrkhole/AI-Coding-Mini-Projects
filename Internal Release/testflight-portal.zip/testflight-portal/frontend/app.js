const API = "";

const $ = (sel) => document.querySelector(sel);
const terminal = $("#terminal");
const btnRelease = $("#btn-release");
const btnAnalyze = $("#btn-analyze");
const btnClearLogs = $("#btn-clear-logs");
const aiOutput = $("#ai-output");
const aiQuestion = $("#ai-question");

let ws = null;
let logBuffer = [];
let terminalCleared = false;

function connectWebSocket() {
  const protocol = location.protocol === "https:" ? "wss:" : "ws:";
  ws = new WebSocket(`${protocol}//${location.host}/ws/logs`);

  ws.onmessage = (event) => {
    if (event.data === "__ping__") return;
    appendLog(event.data);
  };

  ws.onclose = () => setTimeout(connectWebSocket, 2000);
}

function appendLog(line) {
  logBuffer.push(line);

  if (terminalCleared) {
    terminal.textContent = "";
    terminalCleared = false;
  }

  if (terminal.querySelector(".placeholder")) {
    terminal.innerHTML = "";
  }

  const span = document.createElement("span");
  span.textContent = line + "\n";
  if (/ERROR|error|failed|FAILED/i.test(line)) {
    span.className = "line-error";
  }
  terminal.appendChild(span);
  terminal.scrollTop = terminal.scrollHeight;
}

function updateSteps(steps) {
  if (!steps) return;
  for (const step of steps) {
    const el = document.querySelector(`.step[data-step="${step.id}"]`);
    if (!el) continue;
    el.classList.remove("running", "success", "failed", "pending");
    if (step.status === "running") el.classList.add("running");
    else if (step.status === "success") el.classList.add("success");
    else if (step.status === "failed") el.classList.add("failed");
  }
}

function setReleaseRunning(running) {
  btnRelease.disabled = running;
  btnRelease.classList.toggle("running", running);
  btnRelease.querySelector("span:last-child").textContent = running
    ? "Releasing…"
    : "Release to TestFlight";
}

async function fetchPreview() {
  const res = await fetch(`${API}/api/preview`);
  const data = await res.json();
  $("#current-build").textContent = data.current ?? "—";
  $("#next-build").textContent = data.next ?? "—";
  $("#project-path").textContent = data.csproj_path ?? "";
}

async function fetchHealth() {
  const res = await fetch(`${API}/api/health`);
  const data = await res.json();
  const badges = $("#badges");
  badges.innerHTML = "";

  const appleBadge = document.createElement("span");
  appleBadge.className = `badge ${data.apple_configured ? "ok" : "warn"}`;
  appleBadge.textContent = data.apple_configured ? "Apple ID configured" : "Apple ID missing";
  badges.appendChild(appleBadge);

  const groqBadge = document.createElement("span");
  groqBadge.className = `badge ${data.groq_configured ? "ok" : "warn"}`;
  groqBadge.textContent = data.groq_configured ? "Groq AI ready" : "Groq optional";
  badges.appendChild(groqBadge);
}

async function pollStatus() {
  try {
    const res = await fetch(`${API}/api/status`);
    const data = await res.json();
    updateSteps(data.steps);
    setReleaseRunning(data.status === "running");

    if (data.status === "success" || data.status === "failed") {
      await fetchPreview();
      if (data.status === "failed" && data.error) {
        $("#release-hint").textContent = `Failed: ${data.error}`;
        $("#release-hint").style.color = "var(--error)";
      } else if (data.status === "success") {
        $("#release-hint").textContent = `Build ${data.new_build} uploaded successfully.`;
        $("#release-hint").style.color = "var(--success)";
      }
    }
  } catch {
    /* server may be starting */
  }
}

btnRelease.addEventListener("click", async () => {
  $("#release-hint").textContent = "Release in progress…";
  $("#release-hint").style.color = "var(--text-muted)";

  try {
    const res = await fetch(`${API}/api/release`, { method: "POST" });
    if (!res.ok) {
      const err = await res.json();
      alert(err.detail || "Could not start release");
      return;
    }
    setReleaseRunning(true);
    logBuffer = [];
  } catch (e) {
    alert("Could not reach server. Is it running?");
  }
});

btnClearLogs.addEventListener("click", () => {
  terminal.innerHTML = '<span class="placeholder">Logs cleared (server buffer retained).</span>';
  terminalCleared = true;
});

btnAnalyze.addEventListener("click", async () => {
  btnAnalyze.disabled = true;
  aiOutput.innerHTML = '<span class="ai-loading">Analyzing logs…</span>';

  try {
    const res = await fetch(`${API}/api/analyze`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question: aiQuestion.value || null }),
    });

    const data = await res.json();
    if (!res.ok) {
      aiOutput.innerHTML = `<p class="placeholder">${data.detail || "Analysis failed"}</p>`;
      return;
    }

    const paragraphs = data.analysis.split("\n\n").filter(Boolean);
    aiOutput.innerHTML = paragraphs.map((p) => `<p>${escapeHtml(p)}</p>`).join("");
  } catch {
    aiOutput.innerHTML = '<p class="placeholder">Could not reach AI service.</p>';
  } finally {
    btnAnalyze.disabled = false;
  }
});

aiQuestion.addEventListener("keydown", (e) => {
  if (e.key === "Enter") btnAnalyze.click();
});

function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

connectWebSocket();
fetchPreview();
fetchHealth();
setInterval(pollStatus, 2000);
