# TestFlight Release Portal

One-click portal to release **AgentVizion2Go** iOS builds to TestFlight. Automates your daily workflow:

1. Increment `<ApplicationVersion>` in the MAUI `.csproj`
2. `dotnet publish` with `ArchiveOnBuild=true`
3. Upload the `.ipa` via `xcrun altool`

Optional **Groq AI** assistant analyzes build logs and explains failures (free tier).

## Quick start

```bash
cd testflight-portal
chmod +x start.sh
./start.sh
```

On first run, edit `.env` with your credentials, then run `./start.sh` again.

Open **http://127.0.0.1:8787** in your browser and click **Release to TestFlight**.

## Configuration (`.env`)

| Variable | Description |
|----------|-------------|
| `APPLE_ID` | Your Apple ID email |
| `APPLE_APP_PASSWORD` | App-specific password ([create here](https://appleid.apple.com)) |
| `GROQ_API_KEY` | Optional — free key from [console.groq.com](https://console.groq.com) |
| `CSPROJ_PATH` | Path to `AgentVizion2Go.MAUI.csproj` |
| `PROJECT_ROOT` | Root of the MAUI solution |

**Never commit `.env`** — it contains secrets.

## What the portal does

- Shows current and next build numbers before you release
- Live terminal output over WebSocket
- Step progress: increment → publish → upload
- AI panel (Groq) to summarize logs or answer “why did it fail?”

## Manual equivalent

```bash
# 1. Edit ApplicationVersion in csproj (portal does this automatically)

# 2. Publish
cd /Users/jayendra/Desktop/AgentVizion2Go
dotnet publish AgentVizion2Go.MAUI/AgentVizion2Go.MAUI.csproj \
  -f net9.0-ios -c Release \
  -p:RuntimeIdentifier=ios-arm64 \
  -p:ArchiveOnBuild=true

# 3. Upload
cd AgentVizion2Go.MAUI/bin/Release/net9.0-ios/ios-arm64/publish
xcrun altool --upload-app -f AgentVizion2Go.MAUI.ipa -t ios \
  -u "$APPLE_ID" -p "$APPLE_APP_PASSWORD"
```

## Requirements

- macOS with Xcode command-line tools (`xcrun`)
- .NET 9 SDK with MAUI iOS workload
- Valid signing/provisioning for the app

## Security note

Do not paste app-specific passwords into chat or commit them to git. Use `.env` locally only.
